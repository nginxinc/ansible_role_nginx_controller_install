#!/bin/bash
mkdir /opt/nginx-controller
touch /opt/nginx-controller/k8s-namespace.yaml
